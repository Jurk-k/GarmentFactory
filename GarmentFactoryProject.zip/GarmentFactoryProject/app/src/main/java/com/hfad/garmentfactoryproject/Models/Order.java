package com.hfad.garmentfactoryproject.Models;

public class Order {
    public String id, size, gender;

    public Order() {
    }

    public Order(String id, String size, String gender) {
        this.id = id;
        this.size = size;
        this.gender = gender;
    }
}
