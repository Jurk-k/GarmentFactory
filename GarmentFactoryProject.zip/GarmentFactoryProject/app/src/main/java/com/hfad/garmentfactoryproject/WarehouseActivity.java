package com.hfad.garmentfactoryproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hfad.garmentfactoryproject.Models.AllOrders;
import com.hfad.garmentfactoryproject.Models.Order;


public class WarehouseActivity extends AppCompatActivity {

    private EditText editSize, editGender;
    private DatabaseReference mDataBase;
    private String ORDER_KEY = "Order";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_warehouse);
        init();
    }

    private void init() {
        editSize = findViewById(R.id.clientSize);
        editGender = findViewById(R.id.clientGender);
        mDataBase = FirebaseDatabase.getInstance().getReference(ORDER_KEY);
    }

    //кнопка для сохранения
    public void onClickSave(View view) {
        String id = mDataBase.getKey();
        String size = editSize.getText().toString();
        String gender = editGender.getText().toString();
        Order newOrder = new Order(id, size, gender);
        //проверка на пустые поля
        if (!TextUtils.isEmpty(size) && !TextUtils.isEmpty(gender)) {
            mDataBase.push().setValue(newOrder);
        }
        else{
            Toast.makeText(this, "Пустое поле", Toast.LENGTH_SHORT).show();
        }

    }

    //кнопка открытия всех заказов (вылетает)
    public void onClickRead(View view) {
        Intent i = new Intent(WarehouseActivity.this, AllOrders.class);
        startActivity(i);
    }
    
}